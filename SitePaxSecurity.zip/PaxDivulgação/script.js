//API

const x = document.getElementById("result");
if (typeof(Storage) !== "undefined") {
  x.innerHTML = "Your browser supports Web storage!";
} else {
  x.innerHTML = "Sorry, no Web storage support!";
}


//ao ir para a consola aparece se tudo estiver bem que o Site PAX Security foi carrregado com sucesso

document.addEventListener('DOMContentLoaded', () => {
  console.log("Site PAX Security carregado com sucesso!");
});


//ao clicar no botão no quem somos

function mostrarMensagem() {
  alert('Mais informações em breve!');
}

//para andar pelo card slider entre os diferentes produtos

const wrapper = document.querySelector('.cards-wrapper');
const next = document.querySelector('.next');
const prev = document.querySelector('.prev');

next.addEventListener('click', () => {
  wrapper.scrollBy({ left: 300, behavior: 'smooth' });
});

prev.addEventListener('click', () => {
  wrapper.scrollBy({ left: -300, behavior: 'smooth' });
});

